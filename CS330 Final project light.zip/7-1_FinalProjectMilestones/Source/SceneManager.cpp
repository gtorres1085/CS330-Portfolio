///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// clear allocated memory
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(
	const char* filename,
	std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout
			<< "Successfully loaded image:"
			<< filename
			<< ", width:"
			<< width
			<< ", height:"
			<< height
			<< ", channels:"
			<< colorChannels
			<< std::endl;

		glGenTextures(
			1,
			&textureID);

		glBindTexture(
			GL_TEXTURE_2D,
			textureID);

		// set the texture wrapping parameters
		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_WRAP_S,
			GL_REPEAT);

		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_WRAP_T,
			GL_REPEAT);

		// set texture filtering parameters
		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_MIN_FILTER,
			GL_LINEAR);

		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_MAG_FILTER,
			GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGB8,
				width,
				height,
				0,
				GL_RGB,
				GL_UNSIGNED_BYTE,
				image);
		}

		// if the loaded image is in RGBA format
		else if (colorChannels == 4)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGBA8,
				width,
				height,
				0,
				GL_RGBA,
				GL_UNSIGNED_BYTE,
				image);
		}
		else
		{
			std::cout
				<< "Not implemented to handle image with "
				<< colorChannels
				<< " channels"
				<< std::endl;

			return false;
		}

		// generate the texture mipmaps
		glGenerateMipmap(
			GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);

		glBindTexture(
			GL_TEXTURE_2D,
			0);

		// register the loaded texture
		m_textureIDs[m_loadedTextures].ID =
			textureID;

		m_textureIDs[m_loadedTextures].tag =
			tag;

		m_loadedTextures++;

		return true;
	}

	std::cout
		<< "Could not load image:"
		<< filename
		<< std::endl;

	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(
			GL_TEXTURE0 + i);

		glBindTexture(
			GL_TEXTURE_2D,
			m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(
			1,
			&m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 ***********************************************************/
int SceneManager::FindTextureID(
	std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while (
		(index < m_loadedTextures) &&
		(bFound == false))
	{
		if (
			m_textureIDs[index].tag.compare(tag)
			== 0)
		{
			textureID =
				m_textureIDs[index].ID;

			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(
	std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while (
		(index < m_loadedTextures) &&
		(bFound == false))
	{
		if (
			m_textureIDs[index].tag.compare(tag)
			== 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(
	std::string tag,
	OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;

	while (
		(index < m_objectMaterials.size()) &&
		(bFound == false))
	{
		if (
			m_objectMaterials[index].tag.compare(tag)
			== 0)
		{
			bFound = true;

			material.diffuseColor =
				m_objectMaterials[index].diffuseColor;

			material.specularColor =
				m_objectMaterials[index].specularColor;

			material.shininess =
				m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale =
		glm::scale(scaleXYZ);

	rotationX =
		glm::rotate(
			glm::radians(XrotationDegrees),
			glm::vec3(
				1.0f,
				0.0f,
				0.0f));

	rotationY =
		glm::rotate(
			glm::radians(YrotationDegrees),
			glm::vec3(
				0.0f,
				1.0f,
				0.0f));

	rotationZ =
		glm::rotate(
			glm::radians(ZrotationDegrees),
			glm::vec3(
				0.0f,
				0.0f,
				1.0f));

	translation =
		glm::translate(positionXYZ);

	modelView =
		translation *
		rotationZ *
		rotationY *
		rotationX *
		scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ModelName,
			modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r =
		redColorValue;

	currentColor.g =
		greenColorValue;

	currentColor.b =
		blueColorValue;

	currentColor.a =
		alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			false);

		m_pShaderManager->setVec4Value(
			g_ColorValueName,
			currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			true);

		int textureID = -1;

		textureID =
			FindTextureSlot(textureTag);

		m_pShaderManager->setSampler2DValue(
			g_TextureValueName,
			textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 ***********************************************************/
void SceneManager::SetTextureUVScale(
	float u,
	float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value(
			"UVscale",
			glm::vec2(
				u,
				v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn =
			FindMaterial(
				materialTag,
				material);

		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value(
				"material.diffuseColor",
				material.diffuseColor);

			m_pShaderManager->setVec3Value(
				"material.specularColor",
				material.specularColor);

			m_pShaderManager->setFloatValue(
				"material.shininess",
				material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads the textures used for the desk and laptop.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// Wood texture for the desk
	bReturn = CreateGLTexture(
		"textures/wood_planks_seamless.jpg",
		"desk");

	// Metal texture for the laptop
	bReturn = CreateGLTexture(
		"textures/metal_galvanized_seamless.jpg",
		"laptopMetal");

	// Wallpaper texture for the screen
	bReturn = CreateGLTexture(
		"textures/screen_wallpaper_3.jpg",
		"screen");

	// Dark texture for the keyboard
	bReturn = CreateGLTexture(
		"textures/rubber_circles_seamless.jpg",
		"keyboard");

	// Plastic texture for the touchpad
	bReturn = CreateGLTexture(
		"textures/plastic_pattern_seamless.jpg",
		"touchpad");

	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines how the scene surfaces react to lighting.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	// Desk material
	OBJECT_MATERIAL deskMaterial;

	deskMaterial.diffuseColor =
		glm::vec3(
			0.80f,
			0.70f,
			0.60f);

	deskMaterial.specularColor =
		glm::vec3(
			0.15f,
			0.15f,
			0.15f);

	deskMaterial.shininess =
		8.0f;

	deskMaterial.tag =
		"deskMaterial";

	m_objectMaterials.push_back(
		deskMaterial);


	// Laptop metal material
	OBJECT_MATERIAL metalMaterial;

	metalMaterial.diffuseColor =
		glm::vec3(
			0.75f,
			0.75f,
			0.80f);

	metalMaterial.specularColor =
		glm::vec3(
			0.85f,
			0.85f,
			0.85f);

	metalMaterial.shininess =
		48.0f;

	metalMaterial.tag =
		"metalMaterial";

	m_objectMaterials.push_back(
		metalMaterial);


	// Screen material
	OBJECT_MATERIAL screenMaterial;

	screenMaterial.diffuseColor =
		glm::vec3(
			1.0f,
			1.0f,
			1.0f);

	screenMaterial.specularColor =
		glm::vec3(
			0.15f,
			0.15f,
			0.15f);

	screenMaterial.shininess =
		8.0f;

	screenMaterial.tag =
		"screenMaterial";

	m_objectMaterials.push_back(
		screenMaterial);


	// Keyboard material
	OBJECT_MATERIAL keyboardMaterial;

	keyboardMaterial.diffuseColor =
		glm::vec3(
			0.55f,
			0.55f,
			0.55f);

	keyboardMaterial.specularColor =
		glm::vec3(
			0.10f,
			0.10f,
			0.10f);

	keyboardMaterial.shininess =
		4.0f;

	keyboardMaterial.tag =
		"keyboardMaterial";

	m_objectMaterials.push_back(
		keyboardMaterial);


	// Touchpad material
	OBJECT_MATERIAL touchpadMaterial;

	touchpadMaterial.diffuseColor =
		glm::vec3(
			0.70f,
			0.70f,
			0.70f);

	touchpadMaterial.specularColor =
		glm::vec3(
			0.30f,
			0.30f,
			0.30f);

	touchpadMaterial.shininess =
		20.0f;

	touchpadMaterial.tag =
		"touchpadMaterial";

	m_objectMaterials.push_back(
		touchpadMaterial);


	// Ceramic material for coffee mug
	OBJECT_MATERIAL ceramicMaterial;

	ceramicMaterial.diffuseColor =
		glm::vec3(
			0.75f,
			0.75f,
			0.75f);

	ceramicMaterial.specularColor =
		glm::vec3(
			0.85f,
			0.85f,
			0.85f);

	ceramicMaterial.shininess =
		48.0f;

	ceramicMaterial.tag =
		"ceramicMaterial";

	m_objectMaterials.push_back(
		ceramicMaterial);

	// Lamp shade material
	OBJECT_MATERIAL lampShadeMaterial;

	lampShadeMaterial.diffuseColor =
		glm::vec3(
			0.85f,
			0.65f,
			0.25f);

	lampShadeMaterial.specularColor =
		glm::vec3(
			0.35f,
			0.30f,
			0.20f);

	lampShadeMaterial.shininess =
		16.0f;

	lampShadeMaterial.tag =
		"lampShadeMaterial";

	m_objectMaterials.push_back(
		lampShadeMaterial);

	// Dark material for the smartphone body
	OBJECT_MATERIAL phoneMaterial;

	phoneMaterial.diffuseColor =
		glm::vec3(
			0.12f,
			0.12f,
			0.14f);

	phoneMaterial.specularColor =
		glm::vec3(
			0.55f,
			0.55f,
			0.55f);

	phoneMaterial.shininess =
		40.0f;

	phoneMaterial.tag =
		"phoneMaterial";

	m_objectMaterials.push_back(
		phoneMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Adds a warm primary light and a softer fill light.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable Phong lighting
	m_pShaderManager->setBoolValue(
		g_UseLightingName,
		true);


	// Primary warm light
	m_pShaderManager->setVec3Value(
		"pointLights[0].position",
		-4.0f,
		7.0f,
		6.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].ambient",
		0.20f,
		0.16f,
		0.12f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse",
		0.90f,
		0.72f,
		0.55f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		1.0f,
		0.85f,
		0.70f);

	m_pShaderManager->setBoolValue(
		"pointLights[0].bActive",
		true);


	// Secondary fill light
	m_pShaderManager->setVec3Value(
		"pointLights[1].position",
		5.0f,
		5.0f,
		2.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].ambient",
		0.08f,
		0.08f,
		0.10f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].diffuse",
		0.45f,
		0.50f,
		0.60f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].specular",
		0.45f,
		0.50f,
		0.60f);

	m_pShaderManager->setBoolValue(
		"pointLights[1].bActive",
		true);


	// Disable unused lights
	m_pShaderManager->setBoolValue(
		"pointLights[2].bActive",
		false);

	m_pShaderManager->setBoolValue(
		"pointLights[3].bActive",
		false);

	m_pShaderManager->setBoolValue(
		"pointLights[4].bActive",
		false);

	m_pShaderManager->setBoolValue(
		"directionalLight.bActive",
		false);

	m_pShaderManager->setBoolValue(
		"spotLight.bActive",
		false);

	m_pShaderManager->setBoolValue(
		"bUseTextureOverlay",
		false);
}

/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load textures
	LoadSceneTextures();

	// Define materials
	DefineObjectMaterials();

	// Configure lighting
	SetupSceneLights();

	// Load meshes
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadConeMesh();
}

/***********************************************************
 *  RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;

	float XrotationDegrees =
		0.0f;

	float YrotationDegrees =
		0.0f;

	float ZrotationDegrees =
		0.0f;

	glm::vec3 positionXYZ;


	/****************************************************************/
	// FLOOR PLANE
	/****************************************************************/

	scaleXYZ =
		glm::vec3(
			20.0f,
			1.0f,
			10.0f);

	XrotationDegrees =
		0.0f;

	YrotationDegrees =
		0.0f;

	ZrotationDegrees =
		0.0f;

	positionXYZ =
		glm::vec3(
			0.0f,
			0.0f,
			0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture(
		"desk");

	SetTextureUVScale(
		6.0f,
		6.0f);

	SetShaderMaterial(
		"deskMaterial");

	m_basicMeshes->DrawPlaneMesh();


	/****************************************************************/
	// LAPTOP BASE
	/****************************************************************/

	scaleXYZ =
		glm::vec3(
			5.2f,
			0.30f,
			3.4f);

	XrotationDegrees =
		0.0f;

	YrotationDegrees =
		0.0f;

	ZrotationDegrees =
		0.0f;

	positionXYZ =
		glm::vec3(
			0.0f,
			0.25f,
			0.25f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture(
		"laptopMetal");

	SetTextureUVScale(
		1.0f,
		1.0f);

	SetShaderMaterial(
		"metalMaterial");

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	// LAPTOP DISPLAY / LID
	/****************************************************************/

	scaleXYZ =
		glm::vec3(
			5.0f,
			3.05f,
			0.14f);

	XrotationDegrees =
		-12.0f;

	YrotationDegrees =
		0.0f;

	ZrotationDegrees =
		0.0f;

	positionXYZ =
		glm::vec3(
			0.0f,
			1.82f,
			-1.38f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture(
		"laptopMetal");

	SetTextureUVScale(
		1.0f,
		1.0f);

	SetShaderMaterial(
		"metalMaterial");

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	// LEFT LAPTOP HINGE
	/****************************************************************/

	scaleXYZ =
		glm::vec3(
			0.14f,
			0.75f,
			0.14f);

	XrotationDegrees =
		0.0f;

	YrotationDegrees =
		0.0f;

	ZrotationDegrees =
		90.0f;

	positionXYZ =
		glm::vec3(
			-1.75f,
			0.48f,
			-1.30f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture(
		"laptopMetal");

	SetTextureUVScale(
		1.0f,
		1.0f);

	SetShaderMaterial(
		"metalMaterial");

	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/
	// RIGHT LAPTOP HINGE
	/****************************************************************/

	scaleXYZ =
		glm::vec3(
			0.14f,
			0.75f,
			0.14f);

	XrotationDegrees =
		0.0f;

	YrotationDegrees =
		0.0f;

	ZrotationDegrees =
		90.0f;

	positionXYZ =
		glm::vec3(
			1.75f,
			0.48f,
			-1.30f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture(
		"laptopMetal");

	SetTextureUVScale(
		1.0f,
		1.0f);

	SetShaderMaterial(
		"metalMaterial");

	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/
	// DISPLAY PANEL
	/****************************************************************/

	scaleXYZ =
		glm::vec3(
			4.70f,
			2.75f,
			0.05f);

	XrotationDegrees =
		-12.0f;

	YrotationDegrees =
		0.0f;

	ZrotationDegrees =
		0.0f;

	positionXYZ =
		glm::vec3(
			0.0f,
			1.84f,
			-1.27f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture(
		"screen");

	SetTextureUVScale(
		1.0f,
		1.0f);

	SetShaderMaterial(
		"screenMaterial");

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	// KEYBOARD
	/****************************************************************/

	scaleXYZ =
		glm::vec3(
			4.25f,
			0.07f,
			1.80f);

	XrotationDegrees =
		0.0f;

	YrotationDegrees =
		0.0f;

	ZrotationDegrees =
		0.0f;

	positionXYZ =
		glm::vec3(
			0.0f,
			0.43f,
			0.15f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture(
		"keyboard");

	SetTextureUVScale(
		4.0f,
		2.0f);

	SetShaderMaterial(
		"keyboardMaterial");

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	// TOUCHPAD
	/****************************************************************/

	scaleXYZ =
		glm::vec3(
			1.45f,
			0.08f,
			0.75f);

	XrotationDegrees =
		0.0f;

	YrotationDegrees =
		0.0f;

	ZrotationDegrees =
		0.0f;

	positionXYZ =
		glm::vec3(
			0.0f,
			0.47f,
			1.20f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture(
		"touchpad");

	SetTextureUVScale(
		1.0f,
		1.0f);

	SetShaderMaterial(
		"touchpadMaterial");

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	// COFFEE MUG BODY
	/****************************************************************/

	scaleXYZ =
		glm::vec3(
			0.65f,
			1.25f,
			0.65f);

	XrotationDegrees =
		0.0f;

	YrotationDegrees =
		0.0f;

	ZrotationDegrees =
		0.0f;

	positionXYZ =
		glm::vec3(
			3.4f,
			0.05f,
			0.40f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.70f,
		0.12f,
		0.10f,
		1.0f);

	SetShaderMaterial(
		"ceramicMaterial");

	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/
	// COFFEE MUG HANDLE
	/****************************************************************/

	scaleXYZ = glm::vec3(
		0.48f,
		0.14f,
		0.48f);

	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		4.02f,
		0.68f,
		0.40f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.70f,
		0.12f,
		0.10f,
		1.0f);

	SetShaderMaterial(
		"ceramicMaterial");

	m_basicMeshes->DrawTorusMesh();

	/****************************************************************/
// DESK LAMP
// A simple angled desk lamp built from cylinders and a cone.
/****************************************************************/

// -------------------------------------------------------------
// LAMP BASE
// -------------------------------------------------------------
	scaleXYZ = glm::vec3(
		0.80f,
		0.14f,
		0.80f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		-4.0f,
		0.05f,
		0.40f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.18f,
		0.18f,
		0.20f,
		1.0f);

	SetShaderMaterial("metalMaterial");

	m_basicMeshes->DrawCylinderMesh();


	// -------------------------------------------------------------
	// LOWER VERTICAL POST
	// -------------------------------------------------------------
	scaleXYZ = glm::vec3(
		0.12f,
		1.20f,
		0.12f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		-4.0f,
		0.18f,
		0.40f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.22f,
		0.22f,
		0.24f,
		1.0f);

	SetShaderMaterial("metalMaterial");

	m_basicMeshes->DrawCylinderMesh();


	// -------------------------------------------------------------
	// ANGLED UPPER ARM
	// -------------------------------------------------------------
	scaleXYZ = glm::vec3(
		0.11f,
		1.30f,
		0.11f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -40.0f;

	positionXYZ = glm::vec3(
		-4.0f,
		1.25f,
		0.40f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.22f,
		0.22f,
		0.24f,
		1.0f);

	SetShaderMaterial("metalMaterial");

	m_basicMeshes->DrawCylinderMesh();


	// -------------------------------------------------------------
	// LAMP SHADE
	// -------------------------------------------------------------
	scaleXYZ = glm::vec3(
		0.52f,
		0.70f,
		0.52f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -55.0f;

	positionXYZ = glm::vec3(
		-3.20f,
		2.15f,
		0.40f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.85f,
		0.55f,
		0.15f,
		1.0f);

	SetShaderMaterial("lampShadeMaterial");

	m_basicMeshes->DrawConeMesh();
	/****************************************************************/
	// SMARTPHONE BODY
	/****************************************************************/

	scaleXYZ = glm::vec3(
		0.72f,
		0.08f,
		1.35f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = -12.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		-3.05f,
		0.10f,
		2.15f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.08f,
		0.08f,
		0.10f,
		1.0f);

	SetShaderMaterial("phoneMaterial");

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	// SMARTPHONE SCREEN
	/****************************************************************/

	scaleXYZ = glm::vec3(
		0.62f,
		0.025f,
		1.18f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = -12.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(
		-3.05f,
		0.16f,
		2.15f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(
		0.02f,
		0.12f,
		0.18f,
		1.0f);

	SetShaderMaterial("screenMaterial");

	m_basicMeshes->DrawBoxMesh();
}